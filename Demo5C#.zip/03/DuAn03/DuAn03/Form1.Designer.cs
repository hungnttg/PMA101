﻿namespace DuAn03
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            listView1 = new ListView();
            clsMaSach = new ColumnHeader();
            clsTieuDe = new ColumnHeader();
            clsGiamGia = new ColumnHeader();
            clsSoLuong = new ColumnHeader();
            clsSoLuongMua = new ColumnHeader();
            clsNgayMua = new ColumnHeader();
            txtMaSach = new TextBox();
            txtTieuDe = new TextBox();
            txtGia = new TextBox();
            txtSoLuong = new TextBox();
            btnThem = new Button();
            btnUpdate = new Button();
            btnDelete = new Button();
            SuspendLayout();
            // 
            // listView1
            // 
            listView1.Columns.AddRange(new ColumnHeader[] { clsMaSach, clsTieuDe, clsGiamGia, clsSoLuong, clsSoLuongMua, clsNgayMua });
            listView1.Location = new Point(12, 164);
            listView1.Name = "listView1";
            listView1.Size = new Size(748, 253);
            listView1.TabIndex = 0;
            listView1.UseCompatibleStateImageBehavior = false;
            listView1.View = View.Details;
            listView1.SelectedIndexChanged += listView1_SelectedIndexChanged;
            listView1.Click += listView1_Click;
            // 
            // clsMaSach
            // 
            clsMaSach.Text = "Ma Sach";
            // 
            // clsTieuDe
            // 
            clsTieuDe.Text = "Tieu de";
            clsTieuDe.Width = 180;
            // 
            // clsGiamGia
            // 
            clsGiamGia.Text = "Giam gia";
            // 
            // clsSoLuong
            // 
            clsSoLuong.Text = "So Luong";
            clsSoLuong.Width = 100;
            // 
            // txtMaSach
            // 
            txtMaSach.Location = new Point(20, 7);
            txtMaSach.Name = "txtMaSach";
            txtMaSach.Size = new Size(154, 23);
            txtMaSach.TabIndex = 1;
            // 
            // txtTieuDe
            // 
            txtTieuDe.Location = new Point(20, 36);
            txtTieuDe.Name = "txtTieuDe";
            txtTieuDe.Size = new Size(154, 23);
            txtTieuDe.TabIndex = 2;
            // 
            // txtGia
            // 
            txtGia.Location = new Point(20, 65);
            txtGia.Name = "txtGia";
            txtGia.Size = new Size(154, 23);
            txtGia.TabIndex = 3;
            // 
            // txtSoLuong
            // 
            txtSoLuong.Location = new Point(20, 94);
            txtSoLuong.Name = "txtSoLuong";
            txtSoLuong.Size = new Size(154, 23);
            txtSoLuong.TabIndex = 4;
            // 
            // btnThem
            // 
            btnThem.Location = new Point(207, 7);
            btnThem.Name = "btnThem";
            btnThem.Size = new Size(75, 23);
            btnThem.TabIndex = 5;
            btnThem.Text = "Them";
            btnThem.UseVisualStyleBackColor = true;
            btnThem.Click += btnThem_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.Location = new Point(206, 41);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(75, 23);
            btnUpdate.TabIndex = 6;
            btnUpdate.Text = "Update";
            btnUpdate.UseVisualStyleBackColor = true;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(206, 73);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(75, 23);
            btnDelete.TabIndex = 7;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnDelete);
            Controls.Add(btnUpdate);
            Controls.Add(btnThem);
            Controls.Add(txtSoLuong);
            Controls.Add(txtGia);
            Controls.Add(txtTieuDe);
            Controls.Add(txtMaSach);
            Controls.Add(listView1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ListView listView1;
        private ColumnHeader clsMaSach;
        private ColumnHeader clsTieuDe;
        private ColumnHeader clsGiamGia;
        private ColumnHeader clsSoLuong;
        private TextBox txtMaSach;
        private TextBox txtTieuDe;
        private TextBox txtGia;
        private TextBox txtSoLuong;
        private Button btnThem;
        private ColumnHeader clsSoLuongMua;
        private ColumnHeader clsNgayMua;
        private Button btnUpdate;
        private Button btnDelete;
    }
}