﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace DuAn03
{
    public class DB
    {
        SqlConnection conn; //ket noi
        SqlCommand com; //xu ly lenh
        SqlDataAdapter da; //adapter
        DataSet ds; //anh bang du lieu
        public void ketnoi()
        {
            //chuoi ket noi csdl
            string s = "Data Source=.; Initial Catalog=SachDB; Integrated Security=True";
            conn = new SqlConnection(s);//khoi taoket noi
            da = new SqlDataAdapter();//khoi tao bo dieu phoi du lieu
            ds=new DataSet();//khoi tao 
        }
        public void getData(ListView lv) 
        {
            com = new SqlCommand("select * from Products ", conn);//lenh
            da.SelectCommand = com;//select
            da.Fill(ds, "Products");//dien du lieu vao dataset
            lv.Items.Clear();//xoa du lieu tren listview
            for(int rows = 0; rows < ds.Tables[0].Rows.Count;rows++)//chay tu dong 0 den n
            {
                lv.Items.Add(ds.Tables[0].Rows[rows].ItemArray[0].ToString());//them dong
                lv.Items[rows].SubItems.Add(ds.Tables[0].Rows[rows].ItemArray[1].ToString());
                lv.Items[rows].SubItems.Add(ds.Tables[0].Rows[rows].ItemArray[2].ToString());
                lv.Items[rows].SubItems.Add(ds.Tables[0].Rows[rows].ItemArray[3].ToString());
               // lv.Items[rows].SubItems.Add(ds.Tables[0].Rows[rows].ItemArray[4].ToString());
               // lv.Items[rows].SubItems.Add(ds.Tables[0].Rows[rows].ItemArray[5].ToString());
            }
        }
        //ham them du lieu
        public void saveData(TextBox txtMaSach,TextBox txtTenSach,
            TextBox txtGia, TextBox txtSoLuong)
        {
            //lay du lieu tren form va cap nhat vao dataset
            ds.Tables["Products"].Rows.Add(txtMaSach.Text,txtTenSach.Text,
                Convert.ToDecimal(txtGia.Text),Convert.ToInt32(txtSoLuong.Text));
            //chuan bi lenh
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            cb.GetInsertCommand();//thuc hien insert
            da.Update(ds, "Products");//sau khi insert, cap nhat vao dataset
        }
        //sp4.1; lay du lieu tu grid hien thi len textbox
        public void getDataToTextBox(TextBox txtMa,TextBox txtTen,
            TextBox txtGia, TextBox txtSL, ListView lv)
        {
            //1.lay ve chi so dong vua click
            int index = lv.SelectedItems[0].Index;
            //2. Tao doi tuong chua dong du lieu vua clik (DataRow)
            DataRow dr = ds.Tables["Products"].Rows[index];
            //3. Gan du lieu len textbox
            txtMa.Text = dr[0].ToString();
            txtTen.Text = dr[1].ToString();
            txtGia.Text = dr[2].ToString();
            txtSL.Text = dr[3].ToString();

        }
        //sp4.2 update du lieu vao db
        int selectedIndex;//chi so dong
        public void updateData(TextBox txtMa,TextBox txtTen,TextBox txtGia,TextBox txtSL,
            ListView lv)
        {
            //gan chi so cho dong vua chon
            selectedIndex = lv.SelectedItems[0].Index;
            //lay du lieu tu textbox va dua vao dataset
            ds.Tables["Products"].Rows[selectedIndex][1] = txtTen.Text;
            ds.Tables["Products"].Rows[selectedIndex][2] = txtGia.Text;
            ds.Tables["Products"].Rows[selectedIndex][3] = txtSL.Text;
            //su dung doi tuong chua du lieu -> update
            SqlCommandBuilder cb=new SqlCommandBuilder(da);//adapter
            cb.GetUpdateCommand();//loai lenh
            da.Update(ds, "Products");//thuc hien update
        }
        public void deleteData(ListView lv)
        {
            //1. gan chi so cho dong vua chon
            //neu khong chon thi khong lam gi
            int selectedIndex = lv.SelectedItems[0].Index;
            //2.Xoa dong du lieu tu Dataset
            ds.Tables["Products"].Rows[selectedIndex].Delete();
            //3. update dataset vao database
            SqlCommandBuilder cb=new SqlCommandBuilder(da);
            cb.GetDeleteCommand();//lenh thuc hien la delete
            da.Update(ds, "Products");


        }
    }
}
