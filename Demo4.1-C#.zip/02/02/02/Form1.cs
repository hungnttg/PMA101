namespace _02
{
    public partial class Form1 : Form
    {
        DB db
            = new DB();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            db.ketnoi();//goi ham ket noi voi csdl
            db.getData(listView1);
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            //goi ham
            db.saveData(txtMaSach, txtTieuDe, txtGia, txtSoLuong);
            //load lai form
            Form1_Load(null, null);//reload lai form
        }
    }
}