﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _02
{
    public class DB
    {
        SqlConnection conn;//ket noi csdl
        SqlCommand com;//thuc thi lenh
        SqlDataAdapter da;//bo dieu phoi du lieu
        DataSet ds;//anh cua bang du lieu
        public void ketnoi()//ham ket noi
        {
            //chuoi ket noi csdl
            string s
                = "Data Source=.; Initial Catalog=SachDB; Integrated Security=True";
            conn = new SqlConnection(s);//tao ket noi
            da = new SqlDataAdapter();//tao adapter
            ds= new DataSet();//tao dataset
        }
        public void getData(ListView lv)//ham doc du lieu
        {
            //doc du lieu tu db
            com = new SqlCommand("select p.ProductCode,p.Description,p.UnitPrice,p.OnHandQuantity,h.SoLuongMua,h.NgayMua from Products p inner join HoaDon h on p.ProductCode=h.ProductCode", conn);//truyen lenh
            //select p.ProductCode,p.Description,p.UnitPrice,
            //p.OnHandQuantity,h.SoLuongMua,
            //h.NgayMua
            //from Products p inner join HoaDon h on p.ProductCode=h.ProductCode
            da.SelectCommand = com;//xac dinh lenh la select
            da.Fill(ds, "Products");//dien du lieu vao dataset
            //dua du lieu len listview
            lv.Items.Clear();//xoa het du lieu cu
            for(int rows=0; rows < ds.Tables[0].Rows.Count; rows++) 
            {
                //tao dong
                lv.Items.Add(ds.Tables[0].Rows[rows].ItemArray[0].ToString());
                //tao cot
                lv.Items[rows].SubItems.Add(ds.Tables[0].Rows[rows].ItemArray[1].ToString());
                lv.Items[rows].SubItems.Add(ds.Tables[0].Rows[rows].ItemArray[2].ToString());
                lv.Items[rows].SubItems.Add(ds.Tables[0].Rows[rows].ItemArray[3].ToString());
                lv.Items[rows].SubItems.Add(ds.Tables[0].Rows[rows].ItemArray[4].ToString());
                lv.Items[rows].SubItems.Add(ds.Tables[0].Rows[rows].ItemArray[5].ToString());
            }
        }
        public void saveData(TextBox txtMa,TextBox txtTen,TextBox txtGia,TextBox txtSL)
        {
            //lay du lieu tren form va cap nhat vao Dataset
            ds.Tables["Products"].Rows.Add(txtMa.Text,txtTen.Text,
                Convert.ToDecimal(txtGia.Text),Convert.ToInt32(txtSL.Text));
            //chuan bi lenh
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            //thuc hien lenh insert
            cb.GetInsertCommand();
            //sau khi insert vao DB thi cap nhat vao dataset
            da.Update(ds,"Products");
        }

    }
}
