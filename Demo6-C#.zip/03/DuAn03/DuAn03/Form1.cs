namespace DuAn03
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        DB db = new DB();
        private void Form1_Load(object sender, EventArgs e)
        {
            db.ketnoi();
            db.getData(listView1);
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            //goi ham
            db.saveData(txtMaSach, txtTieuDe, txtGia, txtSoLuong);
            //
            Form1_Load(null, null);

        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listView1_Click(object sender, EventArgs e)
        {
            db.getDataToTextBox(txtMaSach, txtTieuDe, txtGia, txtSoLuong, listView1);
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            //goi ham update
            db.updateData(txtMaSach, txtTieuDe, txtGia, txtSoLuong, listView1);
            //reload du lieu
            Form1_Load(null, null);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            db.deleteData(listView1);//thuc hienj xoa
            Form1_Load(null, null);//reload du lieu
        }
    }
}