﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DuAn03
{
    public partial class FrmLogin : Form
    {
        public FrmLogin()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            bool isLogin=DB.login(txtU.Text,txtP.Text);//goi ham login
            if (isLogin)
            {
                MessageBox.Show("Dang nhap thanh cong");
                //goi main form
                Form1 f=new Form1();
                f.Show();
                this.Hide();//an form hien thoi
            }
            else
            {
                MessageBox.Show("Sai user hoac pass");
            }
        }
    }
}
