﻿namespace DuAn03
{
    partial class FrmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtU = new TextBox();
            txtP = new TextBox();
            btnLogin = new Button();
            SuspendLayout();
            // 
            // txtU
            // 
            txtU.Location = new Point(73, 12);
            txtU.Name = "txtU";
            txtU.Size = new Size(141, 23);
            txtU.TabIndex = 0;
            // 
            // txtP
            // 
            txtP.Location = new Point(73, 41);
            txtP.Name = "txtP";
            txtP.Size = new Size(141, 23);
            txtP.TabIndex = 1;
            // 
            // btnLogin
            // 
            btnLogin.Location = new Point(104, 70);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(75, 23);
            btnLogin.TabIndex = 2;
            btnLogin.Text = "Login";
            btnLogin.UseVisualStyleBackColor = true;
            btnLogin.Click += btnLogin_Click;
            // 
            // FrmLogin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(300, 175);
            Controls.Add(btnLogin);
            Controls.Add(txtP);
            Controls.Add(txtU);
            Name = "FrmLogin";
            Text = "FrmLogin";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtU;
        private TextBox txtP;
        private Button btnLogin;
    }
}