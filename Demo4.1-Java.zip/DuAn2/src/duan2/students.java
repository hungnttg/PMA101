/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package duan2;

/**
 *
 * @author admin
 */
public class students {
    private String id,name,email,phone,tinhoc,tienganh;

    public students() {
    }

    public students(String id, String name, String email, String phone,String tinhoc,String tienganh) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.tinhoc=tinhoc;
        this.tienganh=tienganh;
    }

    public String getTienganh() {
        return tienganh;
    }

    public void setTienganh(String tienganh) {
        this.tienganh = tienganh;
    }
    

    public String getTinhoc() {
        return tinhoc;
    }

    public void setTinhoc(String tinhoc) {
        this.tinhoc = tinhoc;
    }
    

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
    
}
