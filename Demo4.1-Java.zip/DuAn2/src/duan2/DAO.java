/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package duan2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author admin
 */
public class DAO {
    //ham ket noi
    public static Connection openConnection() throws ClassNotFoundException, SQLException
    {
        String sql="jdbc:sqlserver://localhost:1433;databaseName=java;integratedSecurity=true";
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        Connection con=DriverManager.getConnection(sql);
        return con;    
    }
    //ham doc du lieu
    public static List loadData()
    {
        List<students> list=new ArrayList<>();
        try {
            String sql="select s.masv,s.hoten,s.email,s.sdt,g.tinhoc,g.tienganh from students s inner join grade g on s.masv=g.masv";
            Connection con=DAO.openConnection();//mo ket noi
            Statement st=con.createStatement();//chuan bi lenh
            ResultSet rs=st.executeQuery(sql);//thuc thi lenh
            while (rs.next()) {            
                //lay ve cac truong du lieu
                String ma=rs.getString(1);
                String ten=rs.getString(2);
                String email=rs.getString(3);
                String phone=rs.getString(4);
                String tinhoc=rs.getString(5);
                String tienganh=rs.getString(6);
                //dua vao doi tuong
                students sv=new students(ma, ma, email, phone,tinhoc,tienganh);
                //dua vao list
                list.add(sv);
            }
            con.close();//dong ket noi
            return list;//tra ve ket qua
        } catch (Exception e) {
        }
        return null;
    }
    public static void insertDataToDB(String ma,String ten,String email,String sdt)
    {
        try {
            Connection con=openConnection();//mo ket noi
            //chuoi truy van
            String sql="insert into students (masv,hoten,email,sdt) values (?,?,?,?)";
            //chuan bi lenh
            PreparedStatement ps=con.prepareStatement(sql);
            //them du lieu vao tham so
            ps.setString(1,ma );
            ps.setString(2,ten );
            ps.setString(3,email );
            ps.setString(4,sdt );
            //thuc thi lenh
            ps.executeUpdate();
        } catch (Exception e) {
        }
    }
}














