namespace DuAn03
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        DB db = new DB();
        private void Form1_Load(object sender, EventArgs e)
        {
            db.ketnoi();
            db.getData(listView1);
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            //goi ham
            db.saveData(txtMaSach,txtTieuDe,txtGia,txtSoLuong);
            //
            Form1_Load(null, null);

        }
    }
}