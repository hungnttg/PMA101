/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package duan03;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author admin
 */
public class DAO {
    //ham ket noi voi CSDL
    public static Connection openConnection() throws ClassNotFoundException, SQLException
    {
        String sql="jdbc:sqlserver://localhost:1433;databaseName=java;integratedSecurity=true";
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        Connection con=DriverManager.getConnection(sql);
        return con;   
    }
    public static void deleteRowInDatabase(String id)
    {
        try {
             String sql="delete from students where masv = ?";//khai bao lenh
            Connection con=DAO.openConnection();//ket noi DB
            PreparedStatement ps=con.prepareStatement(sql);//chuan bi lenh lenh
            ps.setString(1, id);//truyen tham so
            int kq=ps.executeUpdate();//thuc thi lenh
        } catch (Exception e) {
            e.printStackTrace();//bat loi
        }
    }
    public static void loadDataToJTable(DefaultTableModel model)
    {
        try {
            String sql="select * from students";
            Connection con=DAO.openConnection();
            PreparedStatement ps=con.prepareStatement(sql);
            ResultSet rs=ps.executeQuery();
            while (rs.next()) {                
                String masv=rs.getString(1);
                String ten=rs.getString(2);
                String email=rs.getString(3);
                String sdt=rs.getString(4);
                //dua du lieu vao vector
                Vector v=new Vector();//1 dong du lieu
                v.add(masv);//them cac truong
                v.add(ten);
                v.add(email);
                v.add(sdt);
                model.addRow(v);//them dong du lieu vao model
            }
        } catch (Exception e) {
        }
    }
    public static List loadData()
    {
        List<students> list=new ArrayList<>();
        try {
            String sql="select * from students";
            Connection con=DAO.openConnection();
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery(sql);
            while (rs.next()) {                
                String masv=rs.getString(1);
                String ten=rs.getString(2);
                String email=rs.getString(3);
                String sdt=rs.getString(4);
                students sv=new students(sdt, masv, email, sdt);
                list.add(sv);
            }
            con.close();
            return list;
        } catch (Exception e) {
        }
        return null;
    }
    
    public static void insertDataToDB(String ma,String ten,String email, String sdt)
    {
        try {
            Connection con=openConnection();//mo ket noi csdl
            //lenh
            String sql="Insert into students (masv,hoten,email,sdt) values (?,?,?,?)";
            //chuuan bi lenh
            PreparedStatement ps=con.prepareStatement(sql);
            //chuan bi tham so
            ps.setString(1, ma);
            ps.setString(2, ten);
            ps.setString(3, email);
            ps.setString(4, sdt);
            //thuc thi lenh
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
