/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package duan4;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author admin
 */
public class DAO {
    //ket noi
    public static Connection openConnection() 
            throws ClassNotFoundException, SQLException
    {
        //chuoi ket noi
        String sql="jdbc:sqlserver://localhost:1433;databaseName=java;integratedSecurity=true;";
        Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
        Connection con=DriverManager.getConnection(sql);
        return con;
        
    }
    //doc du lieu
    public static List loadData()
    {
        List<students> list=new ArrayList<>();
        try {
            String sql="Select * from students";
            Connection con=DAO.openConnection();
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery(sql);
            while (rs.next()) {                
                String ma=rs.getString(1);
                String ten=rs.getString(2);
                String email=rs.getString(3);
                String phone=rs.getString(4);
                students sv=new  students(ma, ma, email, phone);
                list.add(sv);
            }
            con.close();
            return list;
        } catch (Exception e) {
        }
        return null;
    }
    
    
}















